--[[
    ScoreState Class

    A simple state used to display the player's score before they
    transition back into the play state. Transitioned to from the
    PlayState when they collide with a Pipe.
]]

ScoreState = Class{__includes = BaseState}

--[[
    When we enter the score state, we expect to receive the score
    from the play state so we know what to render to the State.
]]
function ScoreState:enter(params)
    award = "none"
    bronze = love.graphics.newImage('bronze.png')
    silver = love.graphics.newImage('silver.png')
    gold = love.graphics.newImage('gold.png')

    self.score = params.score
    if self.score >1 and self.score <=10 then
        award="bronze"
    elseif self.score>10 and self.score <=15 then
        award ="silver"
    elseif self.score >15 then
        award = "gold"
    end
end

function ScoreState:update(dt)
    -- go back to play if enter is pressed
    if love.keyboard.wasPressed('enter') or love.keyboard.wasPressed('return') then
        gStateMachine:change('countdown')
    end
end

function ScoreState:render()
    -- simply render the score to the middle of the screen
    love.graphics.setFont(flappyFont)
    love.graphics.printf('Oops! Game Over!', 0, 40, VIRTUAL_WIDTH, 'center')

    love.graphics.setFont(mediumFont)
    love.graphics.printf('Score: ' .. tostring(self.score), 0, 80, VIRTUAL_WIDTH, 'center')
    if award =="bronze" then
        love.graphics.printf('Congratulations! You got Bronze Medal!', 0, 150, VIRTUAL_WIDTH, 'center')
        love.graphics.draw(bronze, 230,100)
elseif award =="silver"then
        love.graphics.printf('Congratulations! You got Silver Medal!', 0, 150, VIRTUAL_WIDTH, 'center')
        love.graphics.draw(silver, 230,100)
elseif award =="gold"then
        love.graphics.printf('Congratulations! You got Gold Medal!', 0, 150, VIRTUAL_WIDTH, 'center')
        love.graphics.draw(gold, 230,100)
end

    love.graphics.printf('Press Enter to Play Again!', 0, 190, VIRTUAL_WIDTH, 'center')
end
